# Code Standards

## General

- Keep every file single-purpose: one screen, one route, one job
- Fix root causes; don't patch around a bug with a workaround
- Don't mix UI logic and network calls in the same function —
  network calls go through a small `api.js` helper

## JavaScript (frontend)

- Plain ES modules, no build step (must run directly in an Android
  WebView loaded from `assets/`)
- No frameworks (React etc.) in Phase 1 — keep the WebView light
- Validate any AI response before rendering it (e.g. don't assume
  markdown is always well-formed)

## Backend (Node on Cloudflare Workers / Render)

- Each route file exports one handler with one responsibility
- Validate and parse the request body before any logic runs
- Never log the Anthropic API key or full request bodies containing
  user messages (privacy)

## Styling

- All colors, spacing, and radii come from CSS custom properties
  defined in `style.css` — no hardcoded hex values in components
- Follow the tokens defined in `ui-context.md`

## API Routes

- Validate input first, return a 400 with a clear message on
  invalid input
- Enforce session-id scoping before any database read/write
- Stream AI responses; don't buffer the whole response before
  sending it to the client

## Data and Storage

- Chat messages and session metadata live in Supabase Postgres
- Nothing is cached client-side beyond the current session id

## File Organization

- `app/src/main/assets/` — frontend HTML/CSS/JS
- `app/src/main/assets/components/` — one file per screen
- `backend/src/routes/` — one file per API endpoint
- `backend/src/lib/` — thin SDK wrappers (Anthropic, Supabase)
- `context/` — the six context files + specs (this system)
