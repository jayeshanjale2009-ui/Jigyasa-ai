# UI Context

## Theme

Dark-first. A modern, minimal AI product feel — not a gaming/neon
look. Soft glowing accents used sparingly, glass-style cards for
content surfaces, generous spacing, rounded components.

## Colors

| Role            | CSS Variable       | Value     |
| ---------------- | ------------------ | --------- |
| Page background  | `--bg-base`         | `#0B0D12` |
| Surface (cards)  | `--bg-surface`      | `#161922` |
| Primary text     | `--text-primary`    | `#F2F3F5` |
| Muted text       | `--text-muted`      | `#8A8F9C` |
| Primary accent   | `--accent-primary`  | `#7C5CFF` |
| Border           | `--border-default`  | `#262A35` |
| Error            | `--state-error`     | `#FF5C5C` |
| Success          | `--state-success`   | `#3DDC84` |

## Typography

| Role      | Font              | Variable      |
| --------- | ----------------- | ------------- |
| UI text   | Inter (system fallback) | `--font-sans` |
| Code/mono | JetBrains Mono (system fallback) | `--font-mono` |

## Border Radius

| Context           | Value  |
| ----------------- | ------ |
| Inline / small UI | `8px`  |
| Cards / panels    | `16px` |
| Modals / overlays | `20px` |

## Component Library

No external UI library in Phase 1 — hand-written CSS components in
`style.css`, using the tokens above. Components to build first:
button, input, chat bubble, card, loading spinner, empty state.

## Layout Patterns

- Home: single-column, centered input box, quick-action cards below
  it in a wrap/grid
- Chat: full-height scrollable message list with a fixed input bar
  at the bottom
- Settings: single-column list of grouped options
- Bottom navigation: fixed bar, icons + labels, active state uses
  `--accent-primary`

## Icons

Simple stroke-based icons (e.g. Lucide-style SVGs inlined directly,
no icon library dependency in Phase 1). Sizes: 16px inline, 20px in
buttons and navigation.
