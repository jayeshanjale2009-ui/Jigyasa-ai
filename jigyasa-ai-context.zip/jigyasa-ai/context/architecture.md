# Architecture Context

## Stack

| Layer      | Technology                              | Role |
| ---------- | ---------------------------------------- | ---- |
| Frontend   | HTML + CSS + vanilla JS, Android WebView shell | Renders Home, Chat, Settings; runs as an Android app built entirely in Termux |
| Backend    | Cloudflare Workers (or Render free tier) | Proxies AI requests, keeps the API key server-side, deployed via `git push` |
| AI provider| Anthropic API (Claude)                   | Generates chat responses, called only from the backend |
| Auth + DB  | Supabase (free tier)                     | Guest sessions now, email/Google auth and chat history later |
| Hosting    | GitHub repo (pushed from Termux)         | Source of truth, triggers backend deploy |

## System Boundaries

- `app/src/main/assets/` — all frontend code (HTML/CSS/JS); owns UI rendering and user input only, never calls the AI provider directly
- `app/src/main/assets/components/` — one file per screen (home.js, chat.js, settings.js); owns that screen's DOM and events only
- `backend/src/routes/` — one file per endpoint (chat.js, auth.js); owns request validation and calling external services
- `backend/src/lib/` — thin wrappers around external SDKs (Anthropic, Supabase); owns nothing except talking to that one service

## Storage Model

- **Supabase (Postgres)**: guest session id, chat messages, language/level preference
- **Nowhere (Phase 1)**: no file/blob storage yet — added when Solve Mode / File Assistant arrive

## Auth and Access Model

- Phase 1 uses guest mode only: a random session id is generated on
  first open and stored client-side, sent with every request
- The backend scopes all chat history reads/writes to that session id
- No user can read another session's messages
- Real auth (email/Google via Supabase) is added in a later phase
  without changing this boundary — it just replaces the session id
  with a verified user id

## AI Model

- All AI calls happen server-side in `backend/src/routes/chat.js`
- Requests are streamed from Anthropic back to the client
- The app never holds an API key

## Invariants

1. The Anthropic API key exists only as a backend environment
   variable — never in `app/` code, never committed to git.
2. The frontend (`app/`) never calls the AI provider or Supabase
   directly — every external call goes through `backend/`.
3. Every chat read/write is scoped to the requesting session id;
   there is no endpoint that returns another session's data.
4. Request handlers in `backend/src/routes/` do not do long-running
   work beyond proxying/streaming the AI call — no background jobs
   in Phase 1.
