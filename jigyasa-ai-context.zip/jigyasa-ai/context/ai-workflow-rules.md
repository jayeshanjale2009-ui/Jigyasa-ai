# AI Workflow Rules

## Approach

Build this project incrementally using a spec-driven workflow.
The context files define what to build, how to build it, and the
current state of progress. Always implement against the spec in
`context/specs/` — do not infer or invent product behavior.

## Scoping Rules

- Work on exactly one unit from the build plan at a time
- Prefer small, verifiable increments over large speculative changes
- Do not combine frontend and backend changes in one implementation
  step unless the spec explicitly says so
- Do not install a dependency before the unit that first needs it

## When to Split Work

Split an implementation step if it combines:

- Frontend UI changes and backend route changes
- Two unrelated screens (e.g. Home and Settings) in one step
- Any behavior not clearly defined in `project-overview.md` or the
  current spec file

If a change can't be verified end to end in one sitting on a phone,
the scope is too broad — split it.

## Handling Missing Requirements

- Do not invent product behavior not defined in the context files
- If a requirement is ambiguous, resolve it in the relevant context
  file (usually `project-overview.md` or `architecture.md`) before
  implementing
- If it's still unresolved, add it to "Open Questions" in
  `progress-tracker.md` and stop rather than guessing

## Protected Files

Do not modify the following unless explicitly instructed:

- `context/*.md` — only updated intentionally, not as a side effect
  of implementing a feature
- `backend/.env` — secrets file, never edit or print its contents

## Keeping Docs in Sync

Update the relevant context file whenever implementation changes:

- The stack, folders, or storage model → `architecture.md`
- Naming/styling conventions → `code-standards.md`
- Feature scope → `project-overview.md`
- Visual tokens → `ui-context.md`

## Before Moving to the Next Unit

1. The current unit works end to end within its defined scope
2. No invariant in `architecture.md` was violated
3. `progress-tracker.md` reflects the completed work
4. The app still loads correctly in the Android WebView with no
   console errors
