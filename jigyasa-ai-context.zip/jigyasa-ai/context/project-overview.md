# Jigyasa AI

## Overview

Jigyasa AI ("Ask. Learn. Discover.") is an AI assistant + learning
platform for students, beginners, and programmers. Unlike a generic
chatbot, it explains concepts step by step, adapts to the user's
level (beginner/intermediate/advanced), and supports Hindi, English,
and Hinglish. Phase 1 delivers a working AI chat experience with a
premium, simple UI — the foundation every later mode (Learn, Code,
Solve, Voice) builds on top of.

## Goals

1. A user can open the app and get a real, streamed AI answer to any
   question within Phase 1 — no fake/placeholder AI responses.
2. The app understands and responds naturally in Hindi, English, or
   Hinglish without the user picking a mode.
3. The architecture supports adding Learn Mode, Code Mode, Solve
   Mode, and Voice in later phases without rebuilding the chat core.

## Core User Flow (Phase 1)

1. User opens the app and lands on the Home screen.
2. User types (or taps a quick-action card like "Explain Topic").
3. Message is sent to the backend, which calls the AI provider.
4. Response streams back and renders in the Chat screen with
   markdown/code formatting.
5. User can copy, regenerate, or ask "Samjhao" (explain simpler).
6. User can open Settings to change language or explanation level.

## Features

### Home

- AI input box (text) with placeholder "Ask anything..."
- Quick action cards (Explain Topic, Learn Python, Solve Homework —
  static in Phase 1, wired to real modes later)

### AI Chat

- User messages right-aligned, AI responses left-aligned
- Markdown, code blocks, streaming response
- Actions: Copy, Regenerate, Explain Simpler ("🧠 Samjhao")

### Settings

- Language: Hindi / English / Hinglish
- Explanation level: Beginner / Intermediate / Advanced
- Appearance: Dark (default) / Light / System

## Scope

### In Scope (Phase 1)

- Home screen, AI Chat screen, Settings screen
- Guest mode (no login required to try the app)
- Backend proxy to the AI provider (server-side API key)
- Basic chat history stored per guest session

### Out of Scope (Phase 1 — future phases)

- Learn Mode, Code Mode, Solve Mode, Voice, Research Mode
- Image/file upload and understanding
- Gamification (XP, badges, streaks)
- Email/Google login (guest mode only for now)
- Projects area

## Success Criteria

1. A user can type a question on Home and receive a real streamed
   AI response in the Chat screen.
2. The response renders correctly whether the question is in Hindi,
   English, or Hinglish.
3. No API key is ever present in the app code — only in the backend.
4. The app runs as an Android app built from Termux with no computer.
